module.exports = {
    secret : 'gweriwrb-erfawrg45-oasWsd',
    database : 'http://localhost:4000/' 
};
// (Aka: SESSION_SECRET = 'gweriwrb-erfawrg45-oasWsd';)