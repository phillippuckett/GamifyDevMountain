angular.module("GamifyDevMountain").service("mainSvc", function() {


  // this.toggleDirs = function ( selectedDir ) {
  //   console.log('testing from toggleDirs');
  //   $scope.activeDir.students = false;
  //   $scope.activeDir.badgeAdmin = false;
  //   $scope.activeDir.cohorts = false;
  //   $scope.activeDir.cardAdmin = false;
  //   $scope.activeDir.poptart = false;
  //   $scope.activeDir.curriculumAdmin = false;
  //   $scope.activeDir.categoryAdmin = false;
  //   $scope.activeDir.hideLogo = true;
  //   $scope.activeDir[ selectedDir ] = true;
  //   console.log(selectedDir);
  // };
});
