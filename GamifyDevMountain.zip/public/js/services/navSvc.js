angular.module('GamifyDevMountain')
    .service('navSvc', function ($state, $http) {});