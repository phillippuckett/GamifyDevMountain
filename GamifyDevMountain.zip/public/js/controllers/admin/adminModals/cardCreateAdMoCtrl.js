angular.module("GamifyDevMountain").controller("cardCreateAdMoCtrl", function($scope) {
  
});
