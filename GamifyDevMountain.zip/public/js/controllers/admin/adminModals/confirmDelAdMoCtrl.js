angular.module("GamifyDevMountain").controller("confirmDelAdMoCtrl", function($scope) {

});
