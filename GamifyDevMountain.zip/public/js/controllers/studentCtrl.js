angular.module("GamifyDevMountain")
    .controller("studentCtrl", function ($scope, authSvc, $http) {
        $scope.studentCtrl = "studentCtrl";
        // console.log('Student Controller: Running');
    });