angular.module("GamifyDevMountain").controller("headerCtrl", function($scope) {
//   $scope.user = {
//     firstName: 'Bob',
//     lastName: 'Ross'
//   };
});
