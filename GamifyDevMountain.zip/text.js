 .gitignore                                 |  1 +
 package.json                               |  1 +
 public/css/cores.css                       | 28 +++++++++++++++++++++
 public/html/templates/badgeTmpl.html       |  8 +++++-
 public/html/templates/crudButtonsTmpl.html | 10 ++++----
 public/index.html                          | 17 +++++++------
 public/js/app.js                           |  2 +-
 public/js/controllers/adminCtrl.js         | 40 +++++++++++++++++++++++++++---
 8 files changed, 89 insertions(+), 18 deletions(-)
