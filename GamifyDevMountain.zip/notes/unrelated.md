product owner
responsible for the product success
cares about the user needs and the biz goals
has a vision

empowered to make decisions

team player, dev team and stake holders


slides.com/jeremyrobertson/software-development-lifecycle/live#/3




your rule before you ask a Sr. dev for help
  document a list of things that I've tried before asking a sr. dev
  having a list documented shows that you are thinking about the situation, trying your best, trying not to bother him,.


oh, I can see how you meant that, I must have misunderstood. I'll redo it.

QA is great training for the brain
  if you are doing QA, you need to do devwork on the side to keep up.

  keep that dev portfolio up to date, or it is even harder to get a dev job, than if you had just graduated from a bootcamp.

unit tests
functional tests
etc, many different types of mocha


DevOps


MANAGING UP
  communicate
  push to source often, make sure you are keeping up to date.
  you never know when your job role will change.
  ensure that I am replacable, so that my coworkers don't hate me if they have to take on my project.

myers-briggs personality tests
  analysis paralysis
  pomodoro technique
  don't avoid uknowns.
  taking care of yourself physically
    it has a huge impact on your productivity.
brain is my moneymaker
  take care of long term memory
  cognative process.

brains suck at storage
  great at processing
  slow at loading.

Document your brains
  first step to being hyperproductive
    write down distractions
      related
      unrelated.

mind map
Kanban boards
  trello
  kanbanery.com

decide what you are doing for a week, a month, a day
  plan it once, and stick to it as best I can.


  16personalitites.com

  blog.beeminder.com/akrasia

akrasia
  future you is a dirty and untrustworthy person.

self binding
  make it uncomfortable for future me, to sabotage present me.
find a way to turn positive rewards into soft consequences
  use binding



pomodoro
  count how many pomodoro's that I can succesfuly complete
  if I lose focus, restart the timer.
  upfront analysis paralysis
  drinks, bathroom etc.. retart the timer.

\




*** workplace ethics ***

companies usually do one of the following

  core hours
  set schedule
  fully flexible

don't miss standups or at least report when you do.


standups are also a way to showcase your abilities and ability to stay on task
  prepare answers prior
  be kind

ask for guides, not answers
have links blogs books etc to show that you've tried to find the solution on your own.


make company deadlines, your deadlines (work within hours)

Don't leave your team hanging
  peer reviews
  recommendations
  networking

work to impress your team
git commit every single day

'how to win friends and influence people'

learn how to manage up, hey you're doing a good job, this is going well, but I think I see an imrovement, tell me what you think.

job hoping
it is true that most companies, will not give you a significant raise, they're wanting 5-7 years of tiny bumps.

once I get a little bit of experience under my belt, I can re-evaluate and find better opportunities.

it's common for devs to plan on leaving jobs off and on, find a place they really like, and stick it out for the benifits.


ake sure that they are 10k-30k per yr jumps, not tiny increments. have other reasons that you left, so that you can answer honestly.

I work very hard for 40 hrs, and I get burnt out. I'm not looking for overtime.

negotiate, and show that you are considering if this is a correct fit. interview, the interviewers.

You get one free pass for jumping ships, the second you have two job changes in a short period of time, it looks really suspect on a resume.

go to your current company and try to negotiate when you get a high offer.

most companies are expecting at least 1-2 yrs.

2yrs per hop isn't even questioned.

spit out often websites on the side.

beig a Sr in less than a year, is highly questionable, I'd have to prove my seniority.



SALARY EXPECTATION

our grads are usually in the 40-55 range
luke@mx.com
timeframe was very set, he really wanted to work there and it was a way for him to get his foot in the door.

internships are closer to 40
startups are closer to 40, they usually offer other perks
  paired programming with a Sr.


if you can keep momentum,
  it's key
  if you keep your momentum for a yr, you should be in the 55-65k range for sure
  3-5mos at a lower rate, TOPS..


make sure that you are clear, that you are able to negotiate, if you are leveraging a higher offer.

be careful with highballing.
consider your portfolio, does it fit what I am asking for.

65+ means you can leave me alone for a few weeks, and you won't ever need to help me.
