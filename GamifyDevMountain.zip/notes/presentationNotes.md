### New Technologies ###

Cole did a ton of Ionic work

  Sass, then refactored it to Scss,
  along the way, we learned:
  gulp
  browser-sync
  all about pre- and post-processors.
  we learned how to resolve merge conflicts
    and how to avoid creating many of the common mistakes that lead to merge conflicts.
  we learned about rebase and 3-way merges.

  We really dove into Sass, using many mixins, variables, functions, the works...
  I learned more about Node and the command line interface, even a good deal about VIM.
